package com.example.ej4

import androidx.compose.runtime.mutableStateOf

class StoreViewModel {

    var categoriaSeleccionada = mutableStateOf("")

    val categorias = listOf(
        Categoria("Electronica", R.drawable.electronica),
        Categoria("Ropa", R.drawable.ropa),
        Categoria("Hogar", R.drawable.hogar),
        Categoria("Deportes", R.drawable.deportes),
        Categoria("Juguetes", R.drawable.juguetes)
    )

    fun getProductos(): List<Producto>{

        return when(categoriaSeleccionada.value){

            "Electronica" -> listOf(
                Producto("Laptop rosa", "$15000", R.drawable.laptop, true, true),
                Producto("Audifonos de cable", "$500", R.drawable.audifonos, false, false),
                Producto("Celular motorola", "$8000", R.drawable.celular, true, false),
                Producto("Tablet del mercado", "$6000", R.drawable.tablet, false, true),
                Producto("Smartwatch de temu", "$2000", R.drawable.smartwatch, true, false)
            )

            "Ropa" -> listOf(
                Producto("Playera chida", "$300", R.drawable.playera, true, false),
                Producto("Pantalon cholo", "$700", R.drawable.pantalon, false, true),
                Producto("Sudadera grande", "$900", R.drawable.sudadera, true, false),
                Producto("Zapato (Solo 1)", "$1200", R.drawable.zapato, false, false),
                Producto("Gorra aura", "$200", R.drawable.gorra, true, true)
            )

            "Hogar" -> listOf(
                Producto("Silla gamer", "$800", R.drawable.silla, true, false),
                Producto("Mesa que mas aplauda", "$1500", R.drawable.mesa, false, false),
                Producto("Lampara de lava", "$400", R.drawable.lampara, true, true),
                Producto("Sofa de orangutan", "$5000", R.drawable.sofa, false, false),
                Producto("Cama de hospital", "$7000", R.drawable.cama, true, false)
            )

            "Deportes" -> listOf(
                Producto("Pelota de paw patrol", "$300", R.drawable.pelota, true, false),
                Producto("Raqueta de ping pong", "$600", R.drawable.raqueta, false, true),
                Producto("Pesas de un gramo", "$900", R.drawable.pesas, true, false),
                Producto("Guantes de pelear", "$200", R.drawable.guantes, false, false),
                Producto("Tenis jordan", "$1200", R.drawable.tenis, true, true)
            )

            "Juguetes" -> listOf(
                Producto("Carro de juguete", "$150", R.drawable.carro, true, false),
                Producto("Muñeca horrible", "$250", R.drawable.muneca, false, false),
                Producto("Lego", "$800", R.drawable.lego, true, true),
                Producto("Pelota otra vez", "$100", R.drawable.pelota, false, false),
                Producto("Rompecabezas", "$300", R.drawable.rompecabezas, true, false)
            )

            else -> emptyList()
        }
    }
}