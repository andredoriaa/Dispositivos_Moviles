package com.example.ej4

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun StoreView(vm: StoreViewModel){
    var pantalla by remember { mutableStateOf("categorias") }

    if (pantalla == "categorias") {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Categorias", fontSize = 24.sp, modifier = Modifier.padding(bottom = 16.dp))

            LazyRow() {
                items(vm.categorias) { categoria ->
                    Card(
                        modifier = Modifier
                            .padding(8.dp)
                            .width(130.dp), 
                        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(8.dp).fillMaxWidth()
                        ) {
                            Image(
                                painter = painterResource(id = categoria.imagen),
                                contentDescription = "",
                                modifier = Modifier.size(60.dp)
                            )

                            Text(categoria.nombre, modifier = Modifier.padding(vertical = 4.dp))

                            Button(
                                onClick = {
                                    vm.categoriaSeleccionada.value = categoria.nombre
                                    pantalla = "productos"
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Ver", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    } else {
        ProductosView(vm)
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewStore(){
    StoreView(StoreViewModel())
}