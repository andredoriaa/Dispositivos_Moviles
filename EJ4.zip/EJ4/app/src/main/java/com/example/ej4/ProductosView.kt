package com.example.ej4

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun ProductosView(vm: StoreViewModel){

    val productos = vm.getProductos()

    LazyColumn() {

        items(productos){producto ->

            Card(modifier = Modifier.padding(10.dp), elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Image(
                        painter = painterResource(producto.imagen),
                        contentDescription = "",
                        modifier = Modifier.size(150.dp)
                    )

                    Text(producto.nombre)
                    Text(producto.precio)

                    if (producto.envioGratis){
                        Text("Envio gratis")
                    }

                    if (producto.promo){
                        Text("Promocion!!!! :)")
                    }

                }
            }

        }

    }

}