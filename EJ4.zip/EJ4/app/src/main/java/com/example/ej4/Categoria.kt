package com.example.ej4

data class Categoria(
    val nombre: String,
    val imagen: Int
)
