package com.example.ej4

data class Producto(
    val nombre: String,
    val precio: String,
    val imagen: Int,
    val envioGratis: Boolean,
    val promo: Boolean
)
