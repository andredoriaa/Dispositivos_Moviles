package com.example.primerparcial_20866.EJ3

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.primerparcial_20866.R

@Composable

fun EdadView(edadVM: EdadViewModel){

    var year by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Calcular Edad")

        TextField(
            value = year,
            onValueChange = {year = it},
            label = {Text("Año de nacimiento")}
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {
            edadVM.CalcularEdad(year)
        }) {
            Text("Calcular")
        }


        Spacer(modifier = Modifier.height(20.dp))

        Card(modifier = Modifier.padding(8.dp)) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(20.dp)
            ) {
                if (edadVM.image == "nino"){
                    Image(painter = painterResource(id = R.drawable.nino),
                        contentDescription = "",
                        modifier = Modifier.size(100.dp))
                }

                if (edadVM.image == "joven"){
                    Image(painter = painterResource(id = R.drawable.joven),
                        contentDescription = "",
                        modifier = Modifier.size(100.dp))
                }

                if (edadVM.image == "viejo"){
                    Image(painter = painterResource(id = R.drawable.viejo),
                        contentDescription = "",
                        modifier = Modifier.size(100.dp))
                }

                Text(edadVM.result)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AgePreview(){
    EdadView(EdadViewModel())
}