package com.example.primerparcial_20866.EJ3

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class EdadViewModel {

    var result by mutableStateOf("")
    var image by mutableStateOf("")

    fun CalcularEdad(year: String){

        val edad = 2026 - year.toInt()

        when (edad){

            in 0..14 ->{
                result = "Edad: $edad\nMenor de edad"
                image = "nino"
            }

            15 ->{
                result = "Edad: $edad\nMayor de edad en Indonesia pero no en Mexico"
                image = "joven"
            }

            16 ->{
                result = "Edad: $edad\nMayor de edad en Cuba pero no en Mexico"
                image = "joven"
            }

            17 ->{
                result = "Edad: $edad\nMayor de edad en Corea del norte pero no en Mexico"
                image = "joven"
            }

            18 ->{
                result = "Edad: $edad\nMayor de edad en Mexico pero no en Mexico"
                image = "joven"
            }

            19 ->{
                result = "Edad: $edad\nMayor de edad en Corea del sur pero no en Mexico"
                image = "joven"
            }

            20 ->{
                result = "Edad: $edad\nMayor de edad en Japon"
                image = "joven"
            }

            21 ->{
                result = "Edad: $edad\nMayor de edad en USA"
                image = "joven"
            }

            60 ->{
                result = "Edad: $edad\nEres de la tercera edad"
                image = "joven"
            }

            65 ->{
                result = "Edad: $edad\nYa te puedes jubilar"
                image = "joven"
            }

            else ->{
                result = "Edad: $edad"
                image= "joven"
            }
        }

    }

}